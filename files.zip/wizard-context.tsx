"use client";

import React, { createContext, useContext, useState, useEffect } from "react";

// Types för projektet
export type ProjectType = "renovering" | "tillbyggnad" | "nybyggnation" | "annat" | null;
export type CurrentPhase = "ide" | "skiss" | "ritningar" | "fardigt" | null;

export interface RenoveringRooms {
  badrum?: boolean;
  kok?: boolean;
  vardagsrum?: boolean;
  sovrum?: boolean;
  hall?: boolean;
  tvattrum?: boolean;
  kontor?: boolean;
  annat?: boolean;
}

export interface TillbyggnadData {
  storlek?: string; // "under-20" | "20-50" | "over-50"
  typ?: string; // "enplan" | "tvaplan" | "takterrass"
  befintlig?: string; // "villa" | "radhus" | "kedjehus"
}

export interface NybyggnationData {
  harTomt?: boolean;
  detaljplan?: string; // "ja" | "nej" | "vet-ej"
  bygglov?: string; // "ja" | "pagar" | "nej"
}

export interface WizardData {
  projectType: ProjectType;
  currentPhase: CurrentPhase;
  renovering?: RenoveringRooms;
  tillbyggnad?: TillbyggnadData;
  nybyggnation?: NybyggnationData;
  omfattning?: string;
  budget?: string;
  tidplan?: string;
  mal?: string;
  completedSteps: number;
  totalSteps: number;
}

interface WizardContextType {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
  resetWizard: () => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
  calculateProgress: () => number;
}

const WizardContext = createContext<WizardContextType | undefined>(undefined);

const initialData: WizardData = {
  projectType: null,
  currentPhase: null,
  completedSteps: 0,
  totalSteps: 6,
};

export function WizardProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<WizardData>(initialData);
  const [currentStep, setCurrentStep] = useState(1);

  // Load från localStorage vid mount
  useEffect(() => {
    const saved = localStorage.getItem("byggplattformen-wizard");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setData(parsed);
        // Räkna ut vilket steg baserat på data
        let step = 1;
        if (parsed.projectType) step = 2;
        if (parsed.currentPhase) step = 3;
        if (parsed.omfattning || parsed.renovering || parsed.tillbyggnad || parsed.nybyggnation) step = 4;
        setCurrentStep(step);
      } catch (e) {
        console.error("Failed to parse saved wizard data", e);
      }
    }
  }, []);

  // Spara till localStorage vid varje uppdatering
  useEffect(() => {
    if (data.projectType) {
      localStorage.setItem("byggplattformen-wizard", JSON.stringify(data));
    }
  }, [data]);

  const updateData = (updates: Partial<WizardData>) => {
    setData((prev) => {
      const updated = { ...prev, ...updates };
      
      // Auto-uppdatera totalSteps baserat på projekttyp
      if (updates.projectType) {
        updated.totalSteps = updates.projectType === "renovering" ? 7 : 6;
      }
      
      return updated;
    });
  };

  const resetWizard = () => {
    setData(initialData);
    setCurrentStep(1);
    localStorage.removeItem("byggplattformen-wizard");
  };

  const calculateProgress = () => {
    let completed = 0;
    if (data.projectType) completed++;
    if (data.currentPhase) completed++;
    if (data.renovering || data.tillbyggnad || data.nybyggnation) completed++;
    if (data.omfattning) completed++;
    if (data.tidplan) completed++;
    if (data.mal) completed++;
    
    return Math.round((completed / data.totalSteps) * 100);
  };

  return (
    <WizardContext.Provider
      value={{
        data,
        updateData,
        resetWizard,
        currentStep,
        setCurrentStep,
        calculateProgress,
      }}
    >
      {children}
    </WizardContext.Provider>
  );
}

export function useWizard() {
  const context = useContext(WizardContext);
  if (!context) {
    throw new Error("useWizard must be used within WizardProvider");
  }
  return context;
}
