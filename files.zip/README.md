# Byggplattformen - Intelligent Wizard System

Ett komplett, dynamiskt projektinitierings-wizard som anpassar sig efter användarens val.

## 🎯 Övergripande Flöde

```
/start → Projekttyp
  ↓
/start/nuläge → Nuvarande skede
  ↓
├─ Renovering → /start/renovering (multi-select rum)
├─ Tillbyggnad → /start/tillbyggnad (storlek & typ)
├─ Nybyggnation → /start/nybyggnation (tomt & tillstånd)
└─ Annat → /start/omfattning
  ↓
/start/omfattning → Ytterligare detaljer
  ↓
/start/tidplan → Mål & tidsplan
  ↓
/start/sammanfattning → AI-genererad projektöversikt
```

## 📁 Filstruktur

```
app/
├── start/
│   ├── page.tsx                    # Projekttyp (wizard-context wrapped)
│   ├── nuläge/
│   │   └── page.tsx               # Nuvarande skede
│   ├── renovering/
│   │   └── page.tsx               # Multi-select rum
│   ├── tillbyggnad/
│   │   └── page.tsx               # Storlek & typ
│   ├── nybyggnation/
│   │   └── page.tsx               # Tomt & tillstånd
│   ├── omfattning/
│   │   └── page.tsx               # Detaljer
│   ├── tidplan/
│   │   └── page.tsx               # Mål & tid
│   └── sammanfattning/
│       └── page.tsx               # Final översikt
│
├── components/
│   ├── wizard-context.tsx         # Global state management
│   └── wizard-progress.tsx        # Progress bar component
│
└── layout.tsx                     # Wrap med WizardProvider
```

## 🧩 Komponenter

### 1. `wizard-context.tsx`
- Central state management för hela wizarden
- Sparar automatiskt till localStorage
- Räknar ut progress och totalSteps dynamiskt

### 2. `wizard-progress.tsx`
- Visuell progress bar
- Visar aktuellt steg och uppskattad tid
- "Auto-save" indikator

### 3. Projektspecifika sidor
- **Renovering**: Multi-select checkboxes för rum med metadata (kostnad, tid, komplexitet)
- **Tillbyggnad**: Val av storlek, våningsplan, befintlig byggnad
- **Nybyggnation**: Tomt, detaljplan, bygglovsstatus

## 🎨 Design Features

### Micro-interactions
- ✅ Smooth transitions mellan steg
- ✅ Hover-effekter på cards
- ✅ Animated checkmarks vid val
- ✅ Progress bar som fylls på elegant
- ✅ Auto-save pulsande indikator

### Accessibility
- ✅ Keyboard navigation
- ✅ Focus states
- ✅ ARIA labels
- ✅ "Skip to content" länk
- ✅ Breadcrumbs för orientering

### Responsive
- ✅ Mobile-first design
- ✅ Touch-optimized buttons
- ✅ Adaptive grids (1 col → 2 col)

## 💡 Smarta Features

1. **Conditional Logic**
   - Olika frågor baserat på projekttyp
   - Dynamisk totalSteps räkning

2. **Auto-save**
   - Sparar till localStorage kontinuerligt
   - Kan pausa och återuppta

3. **Progress Persistence**
   - Återställer rätt steg vid reload
   - Visar breadcrumbs

4. **Contextual Help**
   - Tooltips för termer
   - "Bra att veta" tips när rum väljs
   - Risk indicators (komplexitet, bygglov)

5. **Smart Validering**
   - Kan inte gå vidare utan val
   - Visar antal valda items
   - Förhindrar omöjliga kombinationer

## 🚀 Installation

### 1. Kopiera filer till ditt Next.js projekt:

```bash
# Komponenter
cp wizard-context.tsx app/components/
cp wizard-progress.tsx app/components/

# Sidor
cp start-page.tsx app/start/page.tsx
cp nulage-page.tsx app/start/nuläge/page.tsx
cp renovering-page.tsx app/start/renovering/page.tsx
# ... osv för tillbyggnad, nybyggnation
```

### 2. Uppdatera `app/layout.tsx`:

```tsx
import { WizardProvider } from './components/wizard-context';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <WizardProvider>
          {children}
        </WizardProvider>
      </body>
    </html>
  );
}
```

### 3. Lägg till animations i globals.css:

```css
@keyframes fade-in-up {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.animate-fade-in-up {
  animation: fade-in-up 0.6s ease-out forwards;
}
```

## 🎯 Nästa Steg

### Prio 1: Komplettera wizard
- [ ] Skapa tillbyggnad-sida
- [ ] Skapa nybyggnation-sida
- [ ] Skapa omfattning-sida
- [ ] Skapa tidplan-sida
- [ ] Skapa sammanfattning med AI

### Prio 2: Backend Integration
- [ ] Koppla till databas
- [ ] Spara projekt server-side
- [ ] Autentisering (optional i wizard)

### Prio 3: AI Features
- [ ] Generera projektöversikt
- [ ] Riskanalys
- [ ] Kostnadsuppskattning
- [ ] Rekommenderade nästa steg

### Prio 4: Polish
- [ ] Loading states
- [ ] Error handling
- [ ] PDF export
- [ ] Email sammanfattning

## 💬 Varför detta är bättre än Offerta

1. **Struktur först** - inte bara en form
2. **Intelligent guidance** - anpassat efter projekttyp
3. **Transparent process** - inga dolda steg
4. **Pedagogiskt** - lär användaren om processen
5. **Snyggt & modernt** - känns premium

---

**Skapad av:** Claude + Lovable-inspiration 🚀
**Uppdaterad:** 2026-02-04
